package com.example.demo2023_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo20232ApplicationTests {

    @Test
    void contextLoads() {
    }

}
