package com.example.demo2024.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Controlador {


    @GetMapping("/")
    public String doInicio () {
        return "formulario.html";
    }

    @PostMapping("/calcular")
    public String doFormulario (@RequestParam("op1") Integer op1, @RequestParam("op2") Integer op2,
                                @RequestParam("op") String op, Model modelo) {

        modelo.addAttribute("op1", op1);
        modelo.addAttribute("op2", op2);
        modelo.addAttribute("op", op);

        Integer res;
        if(op.equals("+")) res = op1 + op2;
        else if (op.equals("-")) res = op1 - op2;
        else if (op.equals("*")) res = op1 * op2;
        else res = op1 / op2;

        modelo.addAttribute("res", res);

        return "calculadora.jsp";
    }

    @GetMapping("/elegirGenero")
    public String doGenero () { return "genero.jsp"; }

    @PostMapping("/procesarGenero")
    public String doProcesar (@RequestParam("genero") String genero, Model modPrev) {
        modPrev.addAttribute("genero",genero);
        return "tipo.jsp";
    }

    @PostMapping("/procesarTipo")
    public String doTipo (@RequestParam("tipo") String tipo, @RequestParam("modPrev") Model modPrev, Model modelo)
    {
        modPrev.addAttribute("tipo", tipo);

        if(modPrev.containsAttribute("genero")) {
            if(modPrev.getAttribute("genero").equals("terror"))
            {
                if(modPrev.getAttribute("tipo").equals("series"))
                {
                    modPrev.addAttribute("1", "The Walking Dead");
                    modPrev.addAttribute("2", "TWD Daryl Dixon");
                    modPrev.addAttribute("3", "Fear The Walking Dead");
                }
                else
                {
                    modPrev.addAttribute("1", "It");
                    modPrev.addAttribute("2","Insidious");
                    modPrev.addAttribute("3", "Expediente Warren");
                }
            }
            else if(modPrev.getAttribute("genero").equals("cfiction"))
            {
                if(modPrev.getAttribute("tipo").equals("series"))
                {
                    modPrev.addAttribute("1", "The Clone Wars");
                    modPrev.addAttribute("2", "Star Trek Discovery");
                    modPrev.addAttribute("3", "The Mandalorian");
                }
                else
                {
                    modPrev.addAttribute("1", "Star Trek");
                    modPrev.addAttribute("2","Star Wars");
                    modPrev.addAttribute("3", "Time");
                }
            }
            else
            {
                if(modPrev.getAttribute("tipo").equals("series"))
                {
                    modPrev.addAttribute("1", "The Big Bang Theory");
                    modPrev.addAttribute("2", "Modern Family");
                    modPrev.addAttribute("3", "Me llamo Earl");
                }
                else
                {
                    modPrev.addAttribute("1", "Niños Grandes");
                    modPrev.addAttribute("2","Ocho Apellidos Vascos");
                    modPrev.addAttribute("3", "Jack y su Gemela");
                }
            }
        }

        modelo = modPrev;

        return "multimedia.jsp";
    }

    @PostMapping("/mostrarMultimedia")
    public String doMostrar(@RequestParam("modPrev") Model modPrev, @RequestParam("opcion") String[] opciones, Model modelo)
    {
        int i = 0;
        for(String opcion : opciones)
        {
            modPrev.addAttribute("s"+i, opcion);
            i++;
        }

        modelo = modPrev;
        return "informe.jsp";
    }




}
